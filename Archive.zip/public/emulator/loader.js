(function (_0x4307d1, _0x419764) {
  var _0x55d6d7 = a0_0x37ee,
    _0x553dce = _0x4307d1();
  while (!![]) {
    try {
      var _0x167a0f =
        -parseInt(_0x55d6d7(0x1d3, "R1cq")) / 0x1 +
        -parseInt(_0x55d6d7(0x1ae, "RhMc")) / 0x2 +
        parseInt(_0x55d6d7(0x18d, "[gwQ")) / 0x3 +
        -parseInt(_0x55d6d7(0x1d5, "Lv$H")) / 0x4 +
        (parseInt(_0x55d6d7(0x191, "y@Jh")) / 0x5) *
          (parseInt(_0x55d6d7(0x1a1, "8BBx")) / 0x6) +
        -parseInt(_0x55d6d7(0x1d4, "I)lC")) / 0x7 +
        (parseInt(_0x55d6d7(0x1cb, "Fuac")) / 0x8) *
          (parseInt(_0x55d6d7(0x197, "[gwQ")) / 0x9);
      if (_0x167a0f === _0x419764) break;
      else _0x553dce["push"](_0x553dce["shift"]());
    } catch (_0x5284c0) {
      _0x553dce["push"](_0x553dce["shift"]());
    }
  }
})(a0_0xbd6e, 0x8f940);



var ejs_loader = (function (_0x43a89d) {
  function _0x5213cb(_0x1bb90e) {
    var _0x5e2a07 = a0_0x37ee;
    if (_0x51a53b[_0x1bb90e])
      return _0x51a53b[_0x1bb90e][_0x5e2a07(0x1ac, "2YqQ")];
    var _0x818dd1 = (_0x51a53b[_0x1bb90e] = {
      i: _0x1bb90e,
      l: !0x1,
      exports: {},
    });
    return (
      _0x43a89d[_0x1bb90e][_0x5e2a07(0x1e4, "Fuac")](
        _0x818dd1[_0x5e2a07(0x1a0, "BK%g")],
        _0x818dd1,
        _0x818dd1[_0x5e2a07(0x1a5, "Fuac")],
        _0x5213cb
      ),
      (_0x818dd1["l"] = !0x0),
      _0x818dd1["exports"]
    );
  }
  var _0x51a53b = {};
  return (
    (_0x5213cb["m"] = _0x43a89d),
    (_0x5213cb["c"] = _0x51a53b),
    (_0x5213cb["d"] = function (_0x460566, _0xf2ec33, _0x4b0e78) {
      var _0x40effb = a0_0x37ee;
      _0x5213cb["o"](_0x460566, _0xf2ec33) ||
        Object[_0x40effb(0x1c0, "pY5@")](_0x460566, _0xf2ec33, {
          enumerable: !0x0,
          get: _0x4b0e78,
        });
    }),
    (_0x5213cb["r"] = function (_0x325236) {
      var _0x179890 = a0_0x37ee;
      _0x179890(0x1d1, "H#b)") != typeof Symbol &&
        Symbol[_0x179890(0x1aa, "6uyB")] &&
        Object[_0x179890(0x1d8, "lFGO")](
          _0x325236,
          Symbol[_0x179890(0x1be, "W#9@")],
          { value: "Module" }
        ),
        Object[_0x179890(0x18c, "R1cq")](_0x325236, _0x179890(0x1a3, "H#b)"), {
          value: !0x0,
        });
    }),
    (_0x5213cb["t"] = function (_0x3fe939, _0x301b70) {
      var _0x36c41 = a0_0x37ee;
      if (
        (0x1 & _0x301b70 && (_0x3fe939 = _0x5213cb(_0x3fe939)), 0x8 & _0x301b70)
      )
        return _0x3fe939;
      if (
        0x4 & _0x301b70 &&
        _0x36c41(0x1bb, "mVL(") == typeof _0x3fe939 &&
        _0x3fe939 &&
        _0x3fe939[_0x36c41(0x1ba, "2YqQ")]
      )
        return _0x3fe939;
      var _0x132362 = Object[_0x36c41(0x195, "H#b)")](null);
      if (
        (_0x5213cb["r"](_0x132362),
        Object["defineProperty"](_0x132362, _0x36c41(0x1a7, "@2VK"), {
          enumerable: !0x0,
          value: _0x3fe939,
        }),
        0x2 & _0x301b70 && _0x36c41(0x19a, "r!i$") != typeof _0x3fe939)
      ) {
        for (var _0x303769 in _0x3fe939)
          _0x5213cb["d"](
            _0x132362,
            _0x303769,
            function (_0x3c4216) {
              return _0x3fe939[_0x3c4216];
            }[_0x36c41(0x1b3, "RhMc")](null, _0x303769)
          );
      }
      return _0x132362;
    }),
    (_0x5213cb["n"] = function (_0x187589) {
      var _0x56f6b6 =
        _0x187589 && _0x187589["__esModule"]
          ? function () {
              var _0x26d6f5 = a0_0x37ee;
              return _0x187589[_0x26d6f5(0x192, "m6eJ")];
            }
          : function () {
              return _0x187589;
            };
      return _0x5213cb["d"](_0x56f6b6, "a", _0x56f6b6), _0x56f6b6;
    }),
    (_0x5213cb["o"] = function (_0x24afcc, _0xcb7344) {
      var _0x22f7d1 = a0_0x37ee;
      return Object[_0x22f7d1(0x1d9, "4JEG")][_0x22f7d1(0x1e5, "aIS@")][
        _0x22f7d1(0x19e, "e2Ad")
      ](_0x24afcc, _0xcb7344);
    }),
    (_0x5213cb["p"] = ""),
    _0x5213cb((_0x5213cb["s"] = 0xb))
  );
})({
  0xb: function (_0x16004a, _0x4f15c8, _0x284fef) {
    "use strict";
    var _0x3088ab = a0_0x37ee;
    _0x284fef["r"](_0x4f15c8);
    var _0x31c507 = _0x284fef(0x3),
      _0x267482 = _0x284fef(0x5),
      _0x2c21b0 = _0x284fef["n"](_0x267482);
    !(function (_0x2f0031, _0x25257e, _0x56aa2f, _0x151a53) {
      var _0x1d13e3 = a0_0x37ee,
        _0x9eb47b,
        _0x27f0f2 = _0x151a53[_0x1d13e3(0x1c1, "Mc5$")]("?"),
        _0x21790d = _0x27f0f2[0x0],
        _0x585aaa = _0x27f0f2[0x1],
        _0xfe81d6 = !0x1;
      try {
        window["localStorage"] &&
          window[_0x1d13e3(0x1da, "DIJq")] instanceof Storage &&
          (_0xfe81d6 = !0x0);
      } catch (_0x5e8672) {
        _0xfe81d6 = !0x1;
      }
      var _0x1b1e6d,
        _0xd7c5c5 = function (_0x135d4d, _0x4da44d, _0x5178e1, _0x4f5e40) {
          var _0x3adedb = _0x1d13e3,
            _0x4bb9fe = _0x4da44d[_0x3adedb(0x1b5, "e2Ad")](_0x5178e1),
            _0x37d9fd = _0x4da44d["getElementsByTagName"](_0x5178e1)[0x0];
          (_0x4bb9fe[_0x3adedb(0x198, "JWLd")] = 0x1),
            (_0x4bb9fe[_0x3adedb(0x1bf, "W#9@")] = _0x4f5e40),
            _0x37d9fd[_0x3adedb(0x1a9, "*z@G")][_0x3adedb(0x1bc, "brXK")](
              _0x4bb9fe,
              _0x37d9fd
            ),
            (_0x4bb9fe[_0x3adedb(0x1e2, "e2Ad")] = function () {
              var _0x2f5bbe = _0x3adedb;
              if (_0x2f5bbe(0x18a, "RhMc") == typeof EJS_emulator) {
                var _0x6d7ad2 = {};
                (_0x6d7ad2[_0x2f5bbe(0x1e6, "gA@d")] = EJS_gameUrl),
                  _0x2f5bbe(0x19f, "y@Jh") != typeof EJS_biosUrl &&
                    (_0x6d7ad2[_0x2f5bbe(0x1af, "I)lC")] = EJS_biosUrl),
                  _0x2f5bbe(0x1ad, "JWLd") != typeof EJS_gameID &&
                    (_0x6d7ad2[_0x2f5bbe(0x1df, "Mc5$")] = EJS_gameID),
                  _0x2f5bbe(0x1a6, "brXK") != typeof EJS_gameParentUrl &&
                    (_0x6d7ad2[_0x2f5bbe(0x1c9, "aaVk")] = EJS_gameParentUrl),
                  _0x2f5bbe(0x18a, "RhMc") != typeof EJS_gamePatchUrl &&
                    (_0x6d7ad2[_0x2f5bbe(0x1cc, "DIJq")] = EJS_gamePatchUrl),
                  (_0x6d7ad2[_0x2f5bbe(0x199, "jP*J")] = EJS_core),
                  (_0x6d7ad2[_0x2f5bbe(0x1c7, "e2Ad")] = null),
                  (_0x6d7ad2["onloadstate"] = null),
                  _0x2f5bbe(0x196, "9DN)") != typeof EJS_onSaveState &&
                    (_0x6d7ad2[_0x2f5bbe(0x1cf, "6uyB")] = EJS_onSaveState),
                  "undefined" != typeof EJS_onLoadState &&
                    (_0x6d7ad2["onloadstate"] = EJS_onLoadState),
                  _0x2f5bbe(0x1e0, "HXIR") != typeof EJS_lightgun &&
                    (_0x6d7ad2[_0x2f5bbe(0x1dd, "@2VK")] = EJS_lightgun),
                  _0x2f5bbe(0x1b8, "4JEG") != typeof EJS_mouse &&
                    (_0x6d7ad2["mouse"] = EJS_mouse),
                  _0x2f5bbe(0x1d6, "Fuac") != typeof EJS_multitap &&
                    (_0x6d7ad2[_0x2f5bbe(0x1b4, "2YqQ")] = EJS_multitap),
                  _0x2f5bbe(0x1b8, "4JEG") != typeof EJS_playerName &&
                    (_0x6d7ad2[_0x2f5bbe(0x194, "4JEG")] = EJS_playerName),
                  "undefined" != typeof EJS_cheats &&
                    (_0x6d7ad2[_0x2f5bbe(0x19c, "BK%g")] = EJS_cheats),
                  "undefined" != typeof EJS_color &&
                    (_0x6d7ad2["color"] = EJS_color),
                  (window[_0x2f5bbe(0x190, "8BBx")] = new EJS(
                    EJS_player,
                    _0x6d7ad2
                  )),
                  "undefined" != typeof EJS_onGameStart &&
                    EJS_emulator["on"](
                      _0x2f5bbe(0x1a8, "Ogij"),
                      EJS_onGameStart
                    );
              }
            });
        };
      _0xfe81d6 &&
        (_0x9eb47b = localStorage[_0x1d13e3(0x1b6, "^**S")](_0x21790d)) &&
        ((_0x1b1e6d = _0x9eb47b[_0x1d13e3(0x1b9, "6uyB")]("|")),
        _0x9eb47b["substring"](0x0, _0x1b1e6d) == _0x585aaa
          ? ((_0x151a53 = URL[_0x1d13e3(0x19b, "W#9@")](
              new Blob([_0x9eb47b["substring"](_0x1b1e6d + 0x1)], {
                type: _0x1d13e3(0x1b0, "H#b)"),
              })
            )),
            _0xd7c5c5(0x0, _0x25257e, _0x56aa2f, _0x151a53))
          : (_0x9eb47b = null));
      if (!_0x9eb47b) {
        if (_0x1d13e3(0x1dc, "BK%g") == typeof fetch) {
          var _0x293828 = new XMLHttpRequest();
          _0x1d13e3(0x1b1, "RhMc") in _0x293828 &&
            (_0x293828[_0x1d13e3(0x19d, "brXK")]("load", function () {
              var _0x3d8ecb = _0x1d13e3,
                _0x8dea36 = URL["createObjectURL"](
                  new Blob([_0x293828["responseText"]], {
                    type: "text/javascript",
                  })
                );
              try {
                localStorage[_0x3d8ecb(0x1e3, "JWLd")](
                  _0x21790d,
                  _0x585aaa + "|" + _0x293828[_0x3d8ecb(0x1d7, "H7A%")]
                );
              } catch (_0x2b4a2d) {}
              _0xd7c5c5(0x0, _0x25257e, _0x56aa2f, _0x8dea36);
            }),
            _0x293828[_0x1d13e3(0x1db, "@WSY")]("GET", _0x151a53, !0x0),
            (_0x293828[_0x1d13e3(0x1d2, "7mtD")] = "text"),
            _0x293828[_0x1d13e3(0x1c4, "BK%g")]());
        } else
          fetch(_0x151a53, {})
            ["then"](function (_0x56c19f) {
              var _0x5550c0 = _0x1d13e3;
              return _0x56c19f[_0x5550c0(0x1cd, "$BUR")]();
            })
            [_0x1d13e3(0x1b2, "@WSY")](function (_0x1c8d35) {
              var _0x29abbd = _0x1d13e3,
                _0x4d1caf = URL[_0x29abbd(0x1ce, "4JEG")](
                  new Blob([_0x1c8d35], { type: _0x29abbd(0x1bd, "mVL(") })
                );
              try {
                localStorage[_0x29abbd(0x1a4, "0(nn")](
                  _0x21790d,
                  _0x585aaa + "|" + _0x1c8d35
                );
              } catch (_0x3ffebc) {}
              _0xd7c5c5(0x0, _0x25257e, _0x56aa2f, _0x4d1caf);
            });
      }
    })(
      window,
      document,
      _0x3088ab(0x1ab, "*z@G"),
      [
        _0x3088ab(0x1de, "UFcP") == typeof WebAssembly
          ? _0x2c21b0["a"][_0x3088ab(0x1c6, "Mc5$")]
          : _0x2c21b0["a"][_0x3088ab(0x1ab, "*z@G")],
        _0x3088ab(0x1ca, "B&hs"),
        _0x31c507["a"],
      ][_0x3088ab(0x1c5, "Mc5$")]("")
    );
  },
  0x3: function (_0x5019ff, _0x3e6a55) {
    "use strict";
    var _0x10563c = a0_0x37ee;
    _0x3e6a55["a"] = _0x10563c(0x18f, "H#b)");
  },
  0x5: function (_0x18438f) {
    var _0x747845 = a0_0x37ee;
    _0x18438f["exports"] = {
      script: _0x747845(0x1e1, "7mtD"),
      scriptLegacy: _0x747845(0x18b, "e2Ad"),
    };
  },
})["default"];


function a0_0x37ee(_0x4435d2, _0x4c3b7d) {
  var _0xbd6e78 = a0_0xbd6e();
  return (
    (a0_0x37ee = function (_0x37ee0d, _0x31641b) {
      _0x37ee0d = _0x37ee0d - 0x18a;
      var _0xbbc0ef = _0xbd6e78[_0x37ee0d];
      if (a0_0x37ee["iaDTJo"] === undefined) {
        var _0x5254dc = function (_0x5213cb) {
          var _0x51a53b =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";
          var _0x1bb90e = "",
            _0x818dd1 = "";
          for (
            var _0x460566 = 0x0, _0xf2ec33, _0x4b0e78, _0x325236 = 0x0;
            (_0x4b0e78 = _0x5213cb["charAt"](_0x325236++));
            ~_0x4b0e78 &&
            ((_0xf2ec33 =
              _0x460566 % 0x4 ? _0xf2ec33 * 0x40 + _0x4b0e78 : _0x4b0e78),
            _0x460566++ % 0x4)
              ? (_0x1bb90e += String["fromCharCode"](
                  0xff & (_0xf2ec33 >> ((-0x2 * _0x460566) & 0x6))
                ))
              : 0x0
          ) {
            _0x4b0e78 = _0x51a53b["indexOf"](_0x4b0e78);
          }
          for (
            var _0x3fe939 = 0x0, _0x301b70 = _0x1bb90e["length"];
            _0x3fe939 < _0x301b70;
            _0x3fe939++
          ) {
            _0x818dd1 +=
              "%" +
              ("00" + _0x1bb90e["charCodeAt"](_0x3fe939)["toString"](0x10))[
                "slice"
              ](-0x2);
          }
          return decodeURIComponent(_0x818dd1);
        };
        var _0x43a89d = function (_0x132362, _0x303769) {
          var _0x3c4216 = [],
            _0x187589 = 0x0,
            _0x56f6b6,
            _0x24afcc = "";
          _0x132362 = _0x5254dc(_0x132362);
          var _0xcb7344;
          for (_0xcb7344 = 0x0; _0xcb7344 < 0x100; _0xcb7344++) {
            _0x3c4216[_0xcb7344] = _0xcb7344;
          }
          for (_0xcb7344 = 0x0; _0xcb7344 < 0x100; _0xcb7344++) {
            (_0x187589 =
              (_0x187589 +
                _0x3c4216[_0xcb7344] +
                _0x303769["charCodeAt"](_0xcb7344 % _0x303769["length"])) %
              0x100),
              (_0x56f6b6 = _0x3c4216[_0xcb7344]),
              (_0x3c4216[_0xcb7344] = _0x3c4216[_0x187589]),
              (_0x3c4216[_0x187589] = _0x56f6b6);
          }
          (_0xcb7344 = 0x0), (_0x187589 = 0x0);
          for (
            var _0x16004a = 0x0;
            _0x16004a < _0x132362["length"];
            _0x16004a++
          ) {
            (_0xcb7344 = (_0xcb7344 + 0x1) % 0x100),
              (_0x187589 = (_0x187589 + _0x3c4216[_0xcb7344]) % 0x100),
              (_0x56f6b6 = _0x3c4216[_0xcb7344]),
              (_0x3c4216[_0xcb7344] = _0x3c4216[_0x187589]),
              (_0x3c4216[_0x187589] = _0x56f6b6),
              (_0x24afcc += String["fromCharCode"](
                _0x132362["charCodeAt"](_0x16004a) ^
                  _0x3c4216[
                    (_0x3c4216[_0xcb7344] + _0x3c4216[_0x187589]) % 0x100
                  ]
              ));
          }
          return _0x24afcc;
        };
        (a0_0x37ee["DefKXM"] = _0x43a89d),
          (_0x4435d2 = arguments),
          (a0_0x37ee["iaDTJo"] = !![]);
      }
      var _0x1fc9e0 = _0xbd6e78[0x0],
        _0x335043 = _0x37ee0d + _0x1fc9e0,
        _0x413c59 = _0x4435d2[_0x335043];
      return (
        !_0x413c59
          ? (a0_0x37ee["iojlpG"] === undefined && (a0_0x37ee["iojlpG"] = !![]),
            (_0xbbc0ef = a0_0x37ee["DefKXM"](_0xbbc0ef, _0x31641b)),
            (_0x4435d2[_0x335043] = _0xbbc0ef))
          : (_0xbbc0ef = _0x413c59),
        _0xbbc0ef
      );
    }),
    a0_0x37ee(_0x4435d2, _0x4c3b7d)
  );
}
function a0_0xbd6e() {
  var _0x33c988 = [
    "W5RcUMPRWO9ag8orfI3cJG",
    "WRaubSkcW6O/aseLWQe",
    "WP4Cng/dQ8oNgaaH",
    "e3ZcRSkfWPdcUCkZW4JdKaRdT8op",
    "W5BdQxxcGmkJuSkfg3KwW5NcLa",
    "W4qyWOJdMCklf8oGAmoeWO4DjMC",
    "aSo6W54MWOvCDbpcHCoaWRfnW6S",
    "i8kIv8o5W7hdVxVdPCox",
    "WPi+C2BdGL58WQzbWO41na",
    "rmohW6JcOSoDrh3cKSkxAHVcQtnj",
    "p3qGWO1WcsNdU1y",
    "i8o0WPtcNSoigq/dKSkqtCkVW48",
    "lCkjWPuc",
    "vCkXxIzasqFcU8oR",
    "zmoximkbW6SDWP89",
    "WQ/cKs3dTeuXWRRdIHG",
    "W6zhuSosW5mS",
    "DSoDWQxdSNxdUSkxWRxdOa",
    "tJBcQSkcWOJdUCkLW4ddSr/dPSoEeSoXWONdL3itWRRdVmoPfJ7cVSo2DwTZWO3cM2SF",
    "oSoxrX3cTCkb",
    "qKTrwK/dUYS",
    "nCkTx8oW",
    "DcldU8k5W6ZcNWRcUe9okq3dMH8",
    "W5pcTSoBWOW+Frq",
    "W4H+bw16W75eCCo3",
    "ESkwxaxcO8olW60SgHi6W7LQchb2y8kErSowWPW4cCkegSkOWQfuW4H/W7JcO8k3WO4MW6VcUuhdVa",
    "WORcUIFdKCo4aSkMohi2W5xcKIZcSW",
    "FMTVtalcHrPgpdxcNa3cHW",
    "amo7W58UWOeumalcRmoQWO4",
    "W5TCzstcUCk3",
    "c1dcPqRcOYZcKmkHbNX4ia",
    "FmkWW7fnC8ohlmkNdmkP",
    "WQnpW7vCv8kcWOe",
    "WOuIvdHQW6j6CSobW5S",
    "p2OUWOb6dX7dQL7dLG",
    "WOGanwVdUCoR",
    "W5/dNmo+fCkPi8k3W5i+",
    "Fg9MsGldONLkcIpcRa",
    "uf1CFvG",
    "W6qPW5/cNSoiqq",
    "iCkCAIzAmG",
    "WPVcHCoupuDkFeVcJ8kjpCkYEeNdLG",
    "q8k3xYjsuW",
    "W70fz2NcVZ1xvdtdQrNdQYxdPctdGW",
    "nSoyrX4",
    "omoSWQWDzCozamkagq",
    "rCkNsIXuvbO",
    "DIJdG2xcSdtcTCkRnuO",
    "WOvPWOddPvOhvJJcUNZdVh0",
    "WRqTnxNdGmoHeHaPmW",
    "WRpdKNpdV8oxvSkL",
    "m8k0q8oZW6xdOgy",
    "W6Kpz0NcRZfxrrW",
    "BmoBiCkiW6OwWP4",
    "W79DW7NdIwOzW4xcShzN",
    "c1VdS3q/W7XoW4ZdLSo4",
    "W4hcU0P+WOTmbSociZJcJa",
    "cfNdS3GHW7W",
    "W4hcQmkBW7tcQSoytW",
    "rebbDL3dTYJcSSkA",
    "WOWNudKOWQiArSoaW64fW596",
    "WPjdW5xcMmoSvSk1",
    "WP8xkh7cOSoKfXmKjsvnW7CPdq",
    "W4P5fwbFW6vpCmo2W7CjW7TsWRuW",
    "nSkrWPuc",
    "W595d2W",
    "W4NcPCkhW6/cSCoyxCka",
    "nSoltHpcOmkaW40TcHm+W6nX",
    "W68pC8oZW47cRI8",
    "W7hcHZ7cHSkBzCkzmmk7W6Wm",
    "oMGRWPX5fd7dRLC",
    "W5ZcUN1VWOfQdG",
    "W7VcJ8koW6JcLCodwmkfWQuX",
    "x8okW5O+WOpcGq",
    "W7upCeNcUYX7rr7dRXJdUG",
    "rmonW4GVW4/cNYveWPHSeNVdJCocnq",
    "WOZcMmoIkefgxu7cSCknoq",
    "WOVcHCos",
    "ACosamkJzmobmSkYdLVdNCoRW79/",
    "W7jwu8oEW64",
    "WOXOWOxdRfShftVcJvVdRutdUW",
    "E8kPW4xdJCkwEuldUmkwB8k6W7ZcVW",
    "u8k6vcC",
    "W6TjvSoz",
    "W7jftCoEW6O8dWyZWPPwW6O",
    "oSoxwbpcOSkaW7S1dGO+",
    "aSo6W58PWO9DDJpcTCoEWPLgW4y",
    "WRLMWO/cPCkfgs3cOSkYi8o5WRvt",
    "amo4aa",
    "z8o5a8kTWQhdRghdK8oBWOBcRa",
    "kmo6WPRcMSo0kW/dNSkkECk6W4y",
    "EGddV8kD",
    "lhqQWPHRgb/dQvNdLSk9W7uBW7/dNa",
  ];
  a0_0xbd6e = function () {
    return _0x33c988;
  };
  return a0_0xbd6e();
}
