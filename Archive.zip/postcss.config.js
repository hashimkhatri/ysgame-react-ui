module.exports = {
    plugins: {
      autoprefixer: {},
      // other PostCSS plugins if needed
    },
  };